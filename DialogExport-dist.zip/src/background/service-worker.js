//#region src/core/constants.ts
var e = {
	status: "idle",
	total: 0,
	current: 0,
	success: 0,
	failed: 0,
	errors: [],
	results: []
}, t = 1500, n = 3e4, r = 1e3, i = 2e3, a = 1e3, o = 3e4;
//#endregion
//#region src/core/download.ts
async function s(e, t) {
	return c(e, t, "text/markdown;charset=utf-8");
}
async function c(e, t, n) {
	let r = l(t, n);
	return { downloadId: await chrome.downloads.download({
		url: r,
		filename: e,
		saveAs: !1,
		conflictAction: "uniquify"
	}) };
}
function l(e, t) {
	let n = new TextEncoder().encode(e), r = 32768, i = "";
	for (let e = 0; e < n.length; e += r) i += String.fromCharCode(...n.subarray(e, e + r));
	return `data:${t};base64,${btoa(i)}`;
}
//#endregion
//#region src/core/export-format.ts
function u(e, t) {
	return t === "txt" ? {
		extension: "txt",
		content: e,
		mimeType: "text/plain;charset=utf-8"
	} : t === "doc" ? {
		extension: "doc",
		content: ee(e),
		mimeType: "application/msword;charset=utf-8"
	} : {
		extension: "md",
		content: e,
		mimeType: "text/markdown;charset=utf-8"
	};
}
function ee(e) {
	return [
		"<!doctype html>",
		"<html>",
		"<head>",
		"<meta charset=\"utf-8\">",
		"<title>DialogExport</title>",
		"<style>",
		"body{font-family:-apple-system,BlinkMacSystemFont,\"Segoe UI\",sans-serif;line-height:1.65;color:#172026;}",
		"pre{white-space:pre-wrap;font-family:Consolas,\"Liberation Mono\",monospace;font-size:11pt;}",
		"</style>",
		"</head>",
		"<body>",
		"<pre>",
		d(e),
		"</pre>",
		"</body>",
		"</html>"
	].join("\n");
}
function d(e) {
	return e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
//#endregion
//#region src/core/filename.ts
var f = /[<>:"/\\|?*\u0000-\u001f]/g, te = /^(con|prn|aux|nul|com[1-9]|lpt[1-9])$/i;
function p(e, t = "untitled-conversation") {
	let n = e.normalize("NFKC").replace(f, " ").replace(/\s+/g, " ").trim().replace(/[. ]+$/g, "");
	return !n || te.test(n) ? t : n.slice(0, 120).trim() || t;
}
function m(e = /* @__PURE__ */ new Date()) {
	let t = (e) => String(e).padStart(2, "0");
	return [
		e.getFullYear(),
		t(e.getMonth() + 1),
		t(e.getDate())
	].join("") + "-" + [
		t(e.getHours()),
		t(e.getMinutes()),
		t(e.getSeconds())
	].join("");
}
function h(e, t, n, r = /* @__PURE__ */ new Date(), i = "md") {
	let a = p(e, "ai").toLowerCase().replace(/\s+/g, "-"), o = p(n), s = String(t).padStart(4, "0"), c = p(i, "md").toLowerCase().replace(/^\.+/, "") || "md";
	return `${a}-${s}-${o}-${m(r)}.${c}`;
}
//#endregion
//#region src/core/logger.ts
var g = "[Dialog-Export]", _ = {
	debug(e, ...t) {},
	info(e, ...t) {
		console.info(g, e, ...t);
	},
	warn(e, ...t) {
		console.warn(g, e, ...t);
	},
	error(e, ...t) {
		console.error(g, e, ...t);
	}
};
//#endregion
//#region src/core/markdown.ts
function ne(e = /* @__PURE__ */ new Date()) {
	let t = (e) => String(e).padStart(2, "0");
	return `${e.getFullYear()}-${t(e.getMonth() + 1)}-${t(e.getDate())} ${t(e.getHours())}:${t(e.getMinutes())}:${t(e.getSeconds())}`;
}
function v(e) {
	let t = [
		`# ${e.title || "untitled-conversation"}`,
		"",
		`平台：${e.platform}`,
		`导出时间：${e.exportedAt}`,
		`来源链接：${e.url}`,
		"",
		"---",
		""
	];
	for (let n of e.messages) {
		let e = re(n.role);
		t.push(`## ${e}`, "", n.content.trim(), "", "---", "");
	}
	return t.join("\n").replace(/\n{4,}/g, "\n\n\n").trimEnd() + "\n";
}
function re(e) {
	switch (e) {
		case "user": return "User";
		case "assistant": return "Assistant";
		case "system": return "System";
		default: return "Unknown";
	}
}
//#endregion
//#region src/core/report.ts
var y = "untitled-conversation";
function ie(e) {
	let t = e.platformName || "ChatGPT", n = [
		e.status === "stopped" ? `# ${t} 部分导出索引` : `# ${t} 导出索引`,
		"",
		`导出时间：${e.exportedAt}`,
		`任务状态：${e.status}`,
		`选择导出：${e.total} 个`,
		`成功：${e.success} 个`,
		`失败：${e.failed} 个`,
		"",
		"---",
		""
	];
	return e.results.length === 0 ? (n.push("本次没有成功导出的对话。", ""), n.join("\n")) : (n.push("| 序号 | 标题 | 文件名 | 原始链接 | 导出时间 |", "|---|---|---|---|---|"), e.results.forEach((e, t) => {
		n.push(`| ${t + 1} | ${x(e.title || y)} | ${x(e.filename)} | ${x(e.url)} | ${x(e.exportedAt)} |`);
	}), n.join("\n") + "\n");
}
function b(e) {
	let t = [
		`# ${e.platformName || "ChatGPT"} 导出失败报告`,
		"",
		`导出时间：${e.exportedAt}`,
		`任务状态：${e.status}`,
		`失败数量：${e.errors.length}`,
		"",
		"---",
		"",
		"| 序号 | 标题 | 原始链接 | 失败原因 |",
		"|---|---|---|---|"
	];
	return e.errors.forEach((e, n) => {
		t.push(`| ${n + 1} | ${x(e.title || y)} | ${x(e.url)} | ${x(e.reason || "unknown error")} |`);
	}), t.join("\n") + "\n";
}
function x(e) {
	return e.replace(/\|/g, "\\|").replace(/\r?\n/g, "<br>").trim();
}
function S(e, t = /* @__PURE__ */ new Date(), n = "chatgpt") {
	return `${n}-export-${e}-${m(t)}.md`;
}
function ae(e = /* @__PURE__ */ new Date()) {
	return ne(e);
}
//#endregion
//#region src/core/sleep.ts
function C(e) {
	return new Promise((t) => globalThis.setTimeout(t, e));
}
//#endregion
//#region src/background/service-worker.ts
var w = q(), T = !1, E = 0, D = "chatgpt", O = "ChatGPT", k = "md", A, j = "dialogExportBackgroundTask", M = oe();
chrome.runtime.onInstalled.addListener(() => {
	_.info("Dialog-Export installed");
}), chrome.runtime.onMessage.addListener((e, t, n) => e.type === "DOWNLOAD_MARKDOWN" ? (s(e.filename, e.markdown).then((e) => n(Q(e))).catch((e) => n($(e, "下载失败"))), !0) : e.type === "DOWNLOAD_EXPORT_FILE" ? (c(e.filename, e.content, e.mimeType).then((e) => n(Q(e))).catch((e) => n($(e, "下载失败"))), !0) : e.type === "START_SELECTED_CONVERSATION_EXPORT" ? (I(e.tabId, e.conversations, {
	platformId: e.platformId,
	platformName: e.platformName,
	format: e.format
}).then((e) => n(Q(e))).catch((e) => n($(e, "启动导出失败"))), !0) : e.type === "STOP_EXPORT_TASK" ? (F().then((e) => n(Q(e))).catch((e) => n($(e, "停止导出失败"))), !0) : e.type === "GET_EXPORT_TASK_STATE" ? (M.then(() => n(Q(w))).catch((e) => n($(e, "读取导出状态失败"))), !0) : !1);
async function oe() {
	try {
		let e = (await chrome.storage.session.get(j))[j];
		if (!e?.state) return;
		w = e.state, T = e.stopRequested, E = e.activeRunId, D = e.platformId || "chatgpt", O = e.platformName || "ChatGPT", k = Z(e.exportFormat), A = e.workerTabId, (w.status === "exporting" || w.status === "stopping") && (A && await z(A), A = void 0, T = !1, w = {
			...w,
			status: "failed",
			currentTitle: "任务因浏览器后台重启而中断",
			errors: [...w.errors, {
				title: w.currentTitle,
				url: w.currentUrl || "",
				reason: "浏览器后台服务已重启，任务已安全终止，请重新开始导出。"
			}]
		}, await N());
	} catch (e) {
		_.warn("Failed to restore export task state", e), w = q();
	}
}
async function N() {
	let e = {
		state: w,
		stopRequested: T,
		activeRunId: E,
		platformId: D,
		platformName: O,
		exportFormat: k,
		workerTabId: A
	};
	try {
		await chrome.storage.session.set({ [j]: e });
	} catch (e) {
		_.warn("Failed to persist export task state", e);
	}
}
async function P(e, t) {
	return e === E ? (w = t(w), await N(), !0) : !1;
}
async function F() {
	return await M, w.status !== "exporting" && w.status !== "stopping" ? w : (T = !0, w = {
		...w,
		status: "stopping"
	}, await N(), w);
}
async function I(e, t, n) {
	if (await M, w.status === "exporting" || w.status === "stopping") return w;
	if (t.length === 0) throw Error("请至少选择一个要导出的对话。");
	T = !1, E += 1;
	let r = E;
	D = ue(n.platformId || Y(t[0]?.url) || "chatgpt"), O = n.platformName || D, k = Z(n.format);
	for (let e of t) le(e.url, D);
	return w = {
		...q(),
		status: "exporting",
		total: t.length,
		currentTitle: t[0]?.title,
		currentUrl: t[0]?.url
	}, await N(), B(r, e, t), w;
}
async function L(e) {
	let t = await chrome.tabs.get(e), n = await chrome.tabs.create({
		windowId: t.windowId,
		url: "about:blank",
		active: !1
	});
	if (!n.id) throw Error("浏览器没有返回工作标签页 ID。");
	return n;
}
async function R(e) {
	if (e !== E) return;
	let t = A;
	A = void 0, t && await z(t), await N();
}
async function z(e) {
	try {
		await chrome.tabs.remove(e);
	} catch {}
}
async function B(e, n, r) {
	try {
		if (A = (await L(n)).id, await N(), !A) throw Error("无法创建批量导出的工作标签页。");
		for (let n = 0; n < r.length; n += 1) {
			if (J(e)) {
				await V(e, "stopped");
				return;
			}
			let i = r[n];
			await P(e, (e) => ({
				...e,
				status: "exporting",
				currentTitle: i.title,
				currentUrl: i.url
			}));
			try {
				await U(A, i.url), await C(ce());
				let t = await G(A), r = t.title || i.title || "untitled-conversation", a = {
					...t,
					title: r,
					url: i.url
				};
				if (a.messages.length === 0) throw Error("当前对话没有可导出的消息。");
				let o = v(a), s = u(o, k), l = h(D, n + 1, r, /* @__PURE__ */ new Date(), s.extension);
				if (!o.trim()) throw Error("当前对话生成的 Markdown 为空。");
				await c(l, s.content, s.mimeType), await P(e, (e) => ({
					...e,
					success: e.success + 1,
					results: [...e.results, {
						title: r,
						url: i.url,
						filename: l,
						exportedAt: a.exportedAt
					}]
				}));
			} catch (t) {
				await P(e, (e) => ({
					...e,
					failed: e.failed + 1,
					errors: [...e.errors, {
						title: i.title,
						url: i.url,
						reason: t instanceof Error ? t.message : "导出失败"
					}]
				}));
			} finally {
				await P(e, (e) => ({
					...e,
					current: Math.min(n + 1, e.total)
				}));
			}
			if (J(e)) {
				await V(e, "stopped");
				return;
			}
			n < r.length - 1 && await C(t);
		}
		await V(e, T ? "stopped" : "completed");
	} catch (t) {
		await P(e, (e) => ({
			...e,
			status: T ? "stopped" : "failed",
			errors: [...e.errors, {
				url: e.currentUrl || "",
				title: e.currentTitle,
				reason: t instanceof Error ? t.message : "批量导出任务异常中断"
			}]
		})), await H(w.status);
	} finally {
		await R(e);
	}
}
async function V(e, t) {
	e === E && (await P(e, (e) => ({
		...e,
		status: t,
		currentTitle: t === "completed" ? "导出完成" : e.currentTitle
	})), await H(t));
}
async function H(e) {
	try {
		let t = /* @__PURE__ */ new Date(), n = ae(t), r = ie({
			exportedAt: n,
			status: e,
			total: w.total,
			success: w.success,
			failed: w.failed,
			results: w.results,
			platformName: O
		});
		if (await s(S("index", t, D), r), w.errors.length > 0) {
			let r = b({
				exportedAt: n,
				status: e,
				errors: w.errors,
				platformName: O
			});
			await s(S("failed", t, D), r);
		}
	} catch (e) {
		_.warn("Failed to download export report", e);
	}
}
async function U(e, t) {
	await chrome.tabs.update(e, {
		url: t,
		active: !1
	}), await W(e);
}
async function W(e) {
	(await chrome.tabs.get(e)).status !== "complete" && await new Promise((t, r) => {
		let i = globalThis.setTimeout(() => {
			chrome.tabs.onUpdated.removeListener(a), r(/* @__PURE__ */ Error("等待会话页面加载超时。"));
		}, n), a = (n, r) => {
			n === e && r.status === "complete" && (globalThis.clearTimeout(i), chrome.tabs.onUpdated.removeListener(a), t());
		};
		chrome.tabs.onUpdated.addListener(a);
	});
}
async function G(e) {
	let t, n = Date.now();
	for (let r = 1; r <= 5; r += 1) {
		let i = o - (Date.now() - n);
		if (i <= 0) break;
		try {
			let t = await de(se(e, { type: "EXPORT_CURRENT_CONVERSATION" }), i, "提取当前会话消息超时。");
			if (t.messages.length === 0) throw Error("当前对话没有可导出的消息。");
			return t;
		} catch (n) {
			t = n, r === 1 && await K(e), r < 5 && await C(a);
		}
	}
	throw Error(t instanceof Error ? t.message : "无法从当前会话页面提取消息。");
}
async function K(e) {
	try {
		await chrome.scripting.executeScript({
			target: { tabId: e },
			files: ["src/content/index.js"]
		});
	} catch {}
}
async function se(e, t) {
	let n = await chrome.tabs.sendMessage(e, t);
	if (!n?.ok) throw Error(n?.error || "当前页面未准备好，请刷新页面后重试。");
	return n.data;
}
function q() {
	return {
		...e,
		errors: [],
		results: []
	};
}
function J(e) {
	return T || e !== E;
}
function ce() {
	return r + Math.floor(Math.random() * (i - r + 1));
}
function le(e, t) {
	let n;
	try {
		n = new URL(e);
	} catch {
		throw Error(`历史会话链接无效：${e}`);
	}
	if (n.protocol !== "https:" || Y(e) !== t) throw Error(`历史会话链接不属于当前平台：${n.hostname}`);
}
function Y(e) {
	if (!e) return null;
	try {
		let t = new URL(e).hostname;
		if (X(t, "doubao.com")) return "doubao";
		if (X(t, "qwen.ai") || X(t, "qwenlm.ai") || X(t, "tongyi.aliyun.com") || X(t, "tongyi.com") || X(t, "qianwen.com")) return "qianwen";
		if (X(t, "gemini.google.com")) return "gemini";
		if (X(t, "yuanbao.tencent.com")) return "yuanbao";
		if (X(t, "kimi.com") || X(t, "kimi.moonshot.cn")) return "kimi";
		if (X(t, "chat.deepseek.com")) return "deepseek";
		if (X(t, "claude.ai") || X(t, "claude.com")) return "claude";
		if (X(t, "grok.com") || X(t, "x.com")) return "grok";
		if (X(t, "chatgpt.com") || X(t, "chat.openai.com")) return "chatgpt";
	} catch {
		return null;
	}
	return null;
}
function X(e, t) {
	return e === t || e.endsWith(`.${t}`);
}
function ue(e) {
	return e.toLowerCase().replace(/[^a-z0-9-]+/g, "-").replace(/^-+|-+$/g, "") || "ai";
}
function Z(e) {
	return e === "txt" || e === "doc" ? e : "md";
}
async function de(e, t, n) {
	let r, i = new Promise((e, i) => {
		r = globalThis.setTimeout(() => i(Error(n)), t);
	});
	try {
		return await Promise.race([e, i]);
	} finally {
		r !== void 0 && globalThis.clearTimeout(r);
	}
}
function Q(e) {
	return {
		ok: !0,
		data: e
	};
}
function $(e, t) {
	return {
		ok: !1,
		error: e instanceof Error ? e.message : t
	};
}
//#endregion
